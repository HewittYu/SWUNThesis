#include <stdio.h>

// Welcome to the programming 欢迎编程
int main() {
	printf("hello world!\n");
	return 0;
}